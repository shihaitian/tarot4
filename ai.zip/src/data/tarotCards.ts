export interface TarotCard {
  id: number;
  name: string;
  nameEn: string;
  numeral: string;
  symbol: string;
  element: string;
  keywords: string[];
  meaning: string;
  reversed: string;
  colors: {
    from: string;
    to: string;
    accent: string;
  };
}

export const tarotCards: TarotCard[] = [
  {
    id: 0, name: '愚者', nameEn: 'The Fool', numeral: '0',
    symbol: '🌀', element: '风 · Air',
    keywords: ['新开始', '自由', '天真', '冒险'],
    meaning: '代表新的旅程与无限可能。像初生婴儿般纯真，不被世俗所束缚，勇敢地迈出第一步。',
    reversed: '鲁莽行事、缺乏计划、逃避责任。',
    colors: { from: '#E8E0F4', to: '#FAF6F0', accent: '#B8A9D4' },
  },
  {
    id: 1, name: '魔术师', nameEn: 'The Magician', numeral: 'I',
    symbol: '✨', element: '风 · Air',
    keywords: ['创造力', '意志', '技能', '资源'],
    meaning: '你拥有实现目标所需的一切资源。将想法付诸行动的时机已到，运用你的天赋创造奇迹。',
    reversed: '才华被浪费、操纵他人、缺乏方向。',
    colors: { from: '#FFF8E7', to: '#FAF6F0', accent: '#C9A96E' },
  },
  {
    id: 2, name: '女祭司', nameEn: 'The High Priestess', numeral: 'II',
    symbol: '🌙', element: '水 · Water',
    keywords: ['直觉', '潜意识', '神秘', '内在智慧'],
    meaning: '倾听内心深处的声音，答案已在你的潜意识中。保持耐心，让智慧自然显现。',
    reversed: '忽视直觉、隐藏的真相、表面化。',
    colors: { from: '#E0E8F4', to: '#F4F0FA', accent: '#7B6BA0' },
  },
  {
    id: 3, name: '女皇', nameEn: 'The Empress', numeral: 'III',
    symbol: '🌸', element: '地 · Earth',
    keywords: ['丰盛', '母性', '自然', '创造'],
    meaning: '丰饶与创造的能量围绕着你。滋养自己和他人，享受生活中的美好事物。',
    reversed: '创造力受阻、依赖他人、忽视自我照顾。',
    colors: { from: '#F0DCD8', to: '#FAF6F0', accent: '#D4A5A0' },
  },
  {
    id: 4, name: '皇帝', nameEn: 'The Emperor', numeral: 'IV',
    symbol: '👑', element: '火 · Fire',
    keywords: ['权威', '稳定', '结构', '领导'],
    meaning: '建立秩序与结构的时刻。以坚定的意志和清晰的头脑引领方向，承担起你的责任。',
    reversed: '过度控制、固执己见、缺乏灵活性。',
    colors: { from: '#FFF0E0', to: '#FAF6F0', accent: '#D4A574' },
  },
  {
    id: 5, name: '教皇', nameEn: 'The Hierophant', numeral: 'V',
    symbol: '🔑', element: '地 · Earth',
    keywords: ['传统', '信仰', '教导', '精神指引'],
    meaning: '寻求精神上的指引与智慧。遵循传统价值观，或向值得信赖的导师学习。',
    reversed: '盲目遵从、反叛传统、自我封闭。',
    colors: { from: '#E8E4F0', to: '#FAF6F0', accent: '#9B8EC4' },
  },
  {
    id: 6, name: '恋人', nameEn: 'The Lovers', numeral: 'VI',
    symbol: '💕', element: '风 · Air',
    keywords: ['爱情', '选择', '和谐', '结合'],
    meaning: '面对重要的选择，跟随内心的声音。无论是爱情还是人生道路，都要忠于真实的自己。',
    reversed: '关系失衡、错误的选择、价值观冲突。',
    colors: { from: '#FCE4E8', to: '#FAF6F0', accent: '#E8A0B0' },
  },
  {
    id: 7, name: '战车', nameEn: 'The Chariot', numeral: 'VII',
    symbol: '⚡', element: '水 · Water',
    keywords: ['意志力', '胜利', '决心', '前进'],
    meaning: '以坚定的决心和强大的意志力克服障碍。控制好内在的矛盾力量，朝目标勇往直前。',
    reversed: '失去控制、方向迷失、内心冲突。',
    colors: { from: '#E0ECF4', to: '#FAF6F0', accent: '#6B98C0' },
  },
  {
    id: 8, name: '力量', nameEn: 'Strength', numeral: 'VIII',
    symbol: '🦁', element: '火 · Fire',
    keywords: ['勇气', '内在力量', '慈悲', '耐心'],
    meaning: '真正的力量来自内心的平静与慈悲。以温柔驯服内心的野兽，用爱与耐心面对挑战。',
    reversed: '自我怀疑、缺乏自信、以力服人。',
    colors: { from: '#FFF4E4', to: '#FAF6F0', accent: '#D4A050' },
  },
  {
    id: 9, name: '隐士', nameEn: 'The Hermit', numeral: 'IX',
    symbol: '🏔️', element: '地 · Earth',
    keywords: ['内省', '智慧', '独处', '寻找'],
    meaning: '退一步，向内在寻找答案。独处的时光是珍贵的自我探索之旅，智慧的灯塔在你心中。',
    reversed: '过度孤立、逃避社交、迷失方向。',
    colors: { from: '#E8E4D8', to: '#FAF6F0', accent: '#8B7E6A' },
  },
  {
    id: 10, name: '命运之轮', nameEn: 'Wheel of Fortune', numeral: 'X',
    symbol: '☸️', element: '火 · Fire',
    keywords: ['命运', '转变', '机遇', '循环'],
    meaning: '命运的齿轮正在转动，变化即将来临。抓住机遇，顺应宇宙的节奏，一切都在最好的安排中。',
    reversed: '运气不佳、抗拒变化、错失时机。',
    colors: { from: '#E8E0F4', to: '#FFF8E7', accent: '#A890D0' },
  },
  {
    id: 11, name: '正义', nameEn: 'Justice', numeral: 'XI',
    symbol: '⚖️', element: '风 · Air',
    keywords: ['公正', '真相', '平衡', '因果'],
    meaning: '因果法则正在运行，公正的结果即将显现。诚实面对自己，做出正确的判断。',
    reversed: '不公正、偏见、逃避后果。',
    colors: { from: '#F0EEF4', to: '#FAF6F0', accent: '#9090B0' },
  },
  {
    id: 12, name: '倒吊人', nameEn: 'The Hanged Man', numeral: 'XII',
    symbol: '🔄', element: '水 · Water',
    keywords: ['放下', '新视角', '牺牲', '等待'],
    meaning: '换一个角度看世界。暂时的停顿不是失败，而是获得新视角的机会。学会放下执念。',
    reversed: '不必要的牺牲、拖延、固执不变。',
    colors: { from: '#E4F0E8', to: '#FAF6F0', accent: '#7BAA90' },
  },
  {
    id: 13, name: '死神', nameEn: 'Death', numeral: 'XIII',
    symbol: '🦋', element: '水 · Water',
    keywords: ['结束', '转变', '新生', '蜕变'],
    meaning: '旧的章节正在结束，为新的开始腾出空间。蜕变虽然痛苦，但蝴蝶终将破茧而出。',
    reversed: '抗拒改变、恐惧结束、停滞不前。',
    colors: { from: '#E8E0EC', to: '#FAF6F0', accent: '#9480A8' },
  },
  {
    id: 14, name: '节制', nameEn: 'Temperance', numeral: 'XIV',
    symbol: '🏺', element: '火 · Fire',
    keywords: ['平衡', '和谐', '耐心', '适度'],
    meaning: '在对立的力量之间找到平衡。耐心地调和，一切都将以最和谐的方式呈现。',
    reversed: '失衡、极端、缺乏耐心。',
    colors: { from: '#E4ECF4', to: '#FAF6F0', accent: '#80A8C8' },
  },
  {
    id: 15, name: '恶魔', nameEn: 'The Devil', numeral: 'XV',
    symbol: '🔗', element: '地 · Earth',
    keywords: ['束缚', '欲望', '阴影', '释放'],
    meaning: '审视那些束缚你的欲望与恐惧。认识到锁链是可以打开的，自由取决于你的觉知。',
    reversed: '打破束缚、面对阴影、重获自由。',
    colors: { from: '#EEE8E4', to: '#FAF6F0', accent: '#A08870' },
  },
  {
    id: 16, name: '塔', nameEn: 'The Tower', numeral: 'XVI',
    symbol: '⚡', element: '火 · Fire',
    keywords: ['突变', '崩塌', '觉醒', '真相'],
    meaning: '突如其来的变化摧毁了虚假的结构。虽然震撼，但这是通往真相和觉醒的必经之路。',
    reversed: '害怕改变、延迟的灾难、个人转变。',
    colors: { from: '#F4E8E0', to: '#FAF6F0', accent: '#C89070' },
  },
  {
    id: 17, name: '星星', nameEn: 'The Star', numeral: 'XVII',
    symbol: '⭐', element: '风 · Air',
    keywords: ['希望', '灵感', '宁静', '祝福'],
    meaning: '希望之星在黑暗中闪耀。这是治愈与灵感的时刻，宇宙正在祝福你的道路。',
    reversed: '失去信心、悲观、缺乏灵感。',
    colors: { from: '#E8E8F4', to: '#FFF8E7', accent: '#A0A8D4' },
  },
  {
    id: 18, name: '月亮', nameEn: 'The Moon', numeral: 'XVIII',
    symbol: '🌙', element: '水 · Water',
    keywords: ['幻象', '直觉', '潜意识', '恐惧'],
    meaning: '月光下的世界充满了幻象与可能。信任你的直觉，穿过迷雾，真相将在黎明时分显现。',
    reversed: '幻觉消散、面对恐惧、真相大白。',
    colors: { from: '#E0E4F4', to: '#F4F0FA', accent: '#8890C0' },
  },
  {
    id: 19, name: '太阳', nameEn: 'The Sun', numeral: 'XIX',
    symbol: '☀️', element: '火 · Fire',
    keywords: ['快乐', '成功', '活力', '光明'],
    meaning: '阳光照耀着你的道路，带来温暖与喜悦。这是成功、快乐与丰盛的时刻，尽情绽放吧！',
    reversed: '短暂的阴云、过度乐观、延迟的成功。',
    colors: { from: '#FFF8E0', to: '#FAF6F0', accent: '#D4B040' },
  },
  {
    id: 20, name: '审判', nameEn: 'Judgement', numeral: 'XX',
    symbol: '🔔', element: '火 · Fire',
    keywords: ['觉醒', '重生', '召唤', '反思'],
    meaning: '宇宙的号角正在吹响，唤醒你内在的使命。回顾过去，释放旧我，迎接灵魂的重生。',
    reversed: '自我怀疑、拒绝改变、错过觉醒。',
    colors: { from: '#F4E8F0', to: '#FAF6F0', accent: '#B890A8' },
  },
  {
    id: 21, name: '世界', nameEn: 'The World', numeral: 'XXI',
    symbol: '🌍', element: '地 · Earth',
    keywords: ['圆满', '完成', '和谐', '成就'],
    meaning: '一个完整的循环即将完成。你已经走过了漫长的旅程，现在是庆祝成就、拥抱圆满的时刻。',
    reversed: '未完成的事项、缺乏完结、延迟满足。',
    colors: { from: '#E8F0E4', to: '#FFF8E7', accent: '#80B880' },
  },
];

export const positionMeanings = {
  past: { label: '过去', desc: '影响现状的过去因素' },
  present: { label: '现在', desc: '当前的处境与能量' },
  future: { label: '未来', desc: '可能的发展方向' },
};
