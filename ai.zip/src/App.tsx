import { useState, useEffect, useCallback, useRef } from 'react';
import { tarotCards, type TarotCard } from './data/tarotCards';

// ─── Star Particles Background ───
function StarParticles() {
  const [particles, setParticles] = useState<Array<{
    id: number; x: number; delay: number; duration: number; char: string; size: number;
  }>>([]);

  useEffect(() => {
    const chars = ['✦', '✧', '·', '⋆', '✵', '♦'];
    const initial = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 8,
      duration: 8 + Math.random() * 12,
      char: chars[Math.floor(Math.random() * chars.length)],
      size: 8 + Math.random() * 8,
    }));
    setParticles(initial);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map(p => (
        <span
          key={p.id}
          className="star-particle"
          style={{
            left: p.x + '%',
            bottom: '-20px',
            animationDelay: p.delay + 's',
            animationDuration: p.duration + 's',
            animationIterationCount: 'infinite',
            fontSize: p.size + 'px',
            opacity: 0.4,
          }}
        >
          {p.char}
        </span>
      ))}
    </div>
  );
}

// ─── Ornament Divider ───
function Ornament({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`}>
      <span className="text-gold-light text-xs">✦</span>
      <div className="h-px w-12 bg-gradient-to-r from-transparent via-gold-light to-transparent" />
      <span className="text-gold text-sm">❖</span>
      <div className="h-px w-12 bg-gradient-to-r from-transparent via-gold-light to-transparent" />
      <span className="text-gold-light text-xs">✦</span>
    </div>
  );
}

// ─── Card Back Component ───
function CardBack({ size = 'normal' }: { size?: 'normal' | 'small' }) {
  const isSmall = size === 'small';
  return (
    <div className={`${isSmall ? 'w-20 h-32' : 'w-40 h-64 md:w-48 md:h-72'} rounded-xl
                     bg-gradient-to-br from-mystic/80 via-lavender to-mystic/60
                     border-2 border-gold/30 flex items-center justify-center
                     shadow-lg relative overflow-hidden`}>
      <div className={`absolute ${isSmall ? 'inset-1.5' : 'inset-3'} border border-gold/20 rounded-lg`} />
      <div className="absolute inset-0 opacity-10">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="absolute text-gold" style={{
            top: `${15 + (i % 3) * 30}%`,
            left: `${15 + Math.floor(i / 3) * 50}%`,
            fontSize: isSmall ? '10px' : '16px',
            opacity: 0.5
          }}>✦</div>
        ))}
      </div>
      <div className={`relative z-10 ${isSmall ? 'w-8 h-8' : 'w-16 h-16'} rounded-full
                       border border-gold/30 flex items-center justify-center`}>
        <span className={`text-gold/60 ${isSmall ? 'text-sm' : 'text-2xl'}`}>☽</span>
      </div>
    </div>
  );
}

// ─── Card Front Component ───
function CardFront({ card }: { card: TarotCard }) {
  return (
    <div
      className="w-40 h-64 md:w-48 md:h-72 rounded-xl border-2 border-gold/40
                 flex flex-col items-center justify-between p-4 shadow-xl relative overflow-hidden"
      style={{
        background: `linear-gradient(135deg, ${card.colors.from}, ${card.colors.to})`
      }}
    >
      <div className="absolute inset-2.5 border border-gold/15 rounded-lg" />
      <div className="relative z-10 text-center">
        <p className="text-xs text-ink-light/50 font-display">{card.numeral}</p>
      </div>
      <div className="relative z-10 flex flex-col items-center">
        <div className="w-20 h-20 rounded-full bg-white/40 border border-gold/20
                        flex items-center justify-center mb-3 shadow-inner">
          <span className="text-4xl">{card.symbol}</span>
        </div>
        <h3 className="text-lg font-serif font-semibold text-ink tracking-wider">{card.name}</h3>
        <p className="text-xs text-ink-light/50 font-display italic">{card.nameEn}</p>
      </div>
      <div className="relative z-10 text-center">
        <p className="text-xs text-ink-light/40">{card.element}</p>
      </div>
      <span className="absolute top-2 left-3 text-gold/20 text-xs">✦</span>
      <span className="absolute top-2 right-3 text-gold/20 text-xs">✦</span>
      <span className="absolute bottom-2 left-3 text-gold/20 text-xs">✦</span>
      <span className="absolute bottom-2 right-3 text-gold/20 text-xs">✦</span>
    </div>
  );
}

// ─── Audio Controller ───
function AudioController() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const gainRef = useRef<GainNode | null>(null);

  const createAmbientMusic = useCallback(() => {
    if (audioContextRef.current) return;
    
    const ctx = new AudioContext();
    audioContextRef.current = ctx;
    
    const masterGain = ctx.createGain();
    masterGain.gain.value = 0.08;
    masterGain.connect(ctx.destination);
    gainRef.current = masterGain;

    // Pad chord - ethereal ambient
    const frequencies = [261.63, 329.63, 392.0, 523.25]; // C4, E4, G4, C5
    
    frequencies.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.value = freq;
      
      // Slow tremolo
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.value = 0.2 + i * 0.1;
      lfoGain.gain.value = 0.3;
      lfo.connect(lfoGain);
      lfoGain.connect(oscGain.gain);
      lfo.start();
      
      oscGain.gain.value = 0.25;
      osc.connect(oscGain);
      oscGain.connect(masterGain);
      osc.start();
      
      oscillatorsRef.current.push(osc, lfo);
    });

    // Add a deep drone
    const drone = ctx.createOscillator();
    drone.type = 'sine';
    drone.frequency.value = 130.81; // C3
    const droneGain = ctx.createGain();
    droneGain.gain.value = 0.15;
    drone.connect(droneGain);
    droneGain.connect(masterGain);
    drone.start();
    oscillatorsRef.current.push(drone);

    // Random bell-like tones
    const playBell = () => {
      if (!audioContextRef.current || audioContextRef.current.state === 'closed') return;
      const bellFreqs = [523.25, 659.25, 783.99, 1046.5, 392.0, 440.0];
      const freq = bellFreqs[Math.floor(Math.random() * bellFreqs.length)];
      
      const bellOsc = ctx.createOscillator();
      const bellGain = ctx.createGain();
      bellOsc.type = 'sine';
      bellOsc.frequency.value = freq;
      bellGain.gain.value = 0.06;
      bellGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 3);
      bellOsc.connect(bellGain);
      bellGain.connect(masterGain);
      bellOsc.start();
      bellOsc.stop(ctx.currentTime + 3);
      
      setTimeout(playBell, 3000 + Math.random() * 5000);
    };
    
    setTimeout(playBell, 2000);
  }, []);

  const toggleMusic = useCallback(() => {
    if (isPlaying) {
      if (audioContextRef.current) {
        audioContextRef.current.suspend();
      }
      setIsPlaying(false);
    } else {
      if (!audioContextRef.current) {
        createAmbientMusic();
      } else {
        audioContextRef.current.resume();
      }
      setIsPlaying(true);
    }
  }, [isPlaying, createAmbientMusic]);

  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  return (
    <>
      <button
        onClick={toggleMusic}
        className={`fixed top-4 right-4 z-50 w-10 h-10 rounded-full 
                   bg-cream/80 backdrop-blur-sm border border-gold/30 
                   flex items-center justify-center transition-all duration-300
                   hover:bg-cream hover:border-gold/50 hover:shadow-lg
                   ${isPlaying ? 'audio-playing' : ''}`}
        title={isPlaying ? '关闭音乐' : '开启音乐'}
      >
        <span className="text-gold text-sm">
          {isPlaying ? '♫' : '♪'}
        </span>
      </button>
    </>
  );
}

// ─── Page: Landing (Question Input) ───
function LandingPage({ onSubmit }: { onSubmit: (q: string) => void }) {
  const [question, setQuestion] = useState('');
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    setTimeout(() => setShowContent(true), 100);
  }, []);

  const handleSubmit = () => {
    if (question.trim()) {
      onSubmit(question.trim());
    }
  };

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-6 py-12 transition-opacity duration-1000 ${showContent ? 'opacity-100' : 'opacity-0'}`}>
      {/* Moon Decoration */}
      <div className="relative mb-10">
        <div className="w-32 h-32 rounded-full bg-gradient-to-br from-gold-light/30 via-lavender-light/40 to-rose-light/30 
                        flex items-center justify-center animate-breathe shadow-lg shadow-gold/10">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-cream via-white to-cream-dark 
                          border border-gold-light/40 flex items-center justify-center">
            <span className="text-4xl text-golden">✦</span>
          </div>
        </div>
        {/* Orbit dots */}
        {[0, 60, 120, 180, 240, 300].map((deg, i) => (
          <div
            key={i}
            className="absolute w-1.5 h-1.5 bg-gold/60 rounded-full"
            style={{
              top: `${64 - 76 * Math.cos((deg * Math.PI) / 180)}px`,
              left: `${64 + 76 * Math.sin((deg * Math.PI) / 180)}px`,
            }}
          />
        ))}
      </div>

      {/* Title */}
      <h1 className="text-5xl md:text-6xl font-serif font-light text-golden tracking-wider mb-3 animate-fadeInUp">
        星辰塔罗
      </h1>
      <p className="text-sm font-display italic text-ink-light/60 mb-2 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
        Celestial Tarot Reading
      </p>
      <Ornament className="mb-10 animate-fadeInUp" />

      {/* Description */}
      <p className="text-ink-light text-center max-w-md mb-8 font-serif text-sm leading-relaxed animate-fadeInUp"
         style={{ animationDelay: '0.3s', opacity: 0 }}>
        欢迎来到星辰塔罗。在这里，宇宙的智慧将为你指引方向。<br />
        请在心中冥想你的问题，然后将它写下来……
      </p>

      {/* Question Input */}
      <div className="w-full max-w-lg animate-fadeInUp" style={{ animationDelay: '0.5s', opacity: 0 }}>
        <div className="relative">
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="写下困扰你的问题……例如：我的事业将走向何方？"
            className="w-full h-32 px-6 py-4 bg-white/60 backdrop-blur-sm rounded-2xl 
                       border border-gold-light/40 text-ink font-serif text-sm
                       placeholder:text-ink-light/30 resize-none
                       focus:outline-none focus:border-gold/60 focus:shadow-lg focus:shadow-gold/10
                       transition-all duration-300"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
          />
          <div className="absolute bottom-3 right-3 text-xs text-ink-light/30 font-display italic">
            按 Enter 开始占卜
          </div>
        </div>
        
        <button
          onClick={handleSubmit}
          disabled={!question.trim()}
          className="mt-6 w-full py-3.5 rounded-xl font-serif text-sm tracking-widest
                     bg-gradient-to-r from-gold-dark/90 via-gold to-gold-dark/90
                     text-cream border border-gold-light/50
                     hover:shadow-lg hover:shadow-gold/20 hover:scale-[1.02]
                     disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100
                     transition-all duration-300"
        >
          ✦ 开始占卜 ✦
        </button>
      </div>

      {/* Bottom hint */}
      <p className="mt-12 text-xs text-ink-light/30 font-display italic animate-float">
        ✧ 让心灵平静，聆听宇宙的声音 ✧
      </p>
    </div>
  );
}

// ─── Page: Card Selection ───
function CardSelectionPage({ 
  question, 
  onComplete 
}: { 
  question: string; 
  onComplete: (cards: TarotCard[]) => void;
}) {
  const [shuffledCards, setShuffledCards] = useState<TarotCard[]>([]);
  const [selectedCards, setSelectedCards] = useState<TarotCard[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<Set<number>>(new Set());
  const [isShuffling, setIsShuffling] = useState(true);
  const [showCards, setShowCards] = useState(false);
  const [allRevealed, setAllRevealed] = useState(false);

  useEffect(() => {
    // Shuffle animation
    const shuffled = [...tarotCards].sort(() => Math.random() - 0.5);
    setShuffledCards(shuffled);
    
    setTimeout(() => {
      setIsShuffling(false);
      setTimeout(() => setShowCards(true), 300);
    }, 2000);
  }, []);

  const selectCard = (card: TarotCard, index: number) => {
    if (selectedCards.length >= 3 || flippedIndices.has(index)) return;
    
    setFlippedIndices(prev => new Set([...prev, index]));
    setSelectedCards(prev => [...prev, card]);

    if (selectedCards.length === 2) {
      // All 3 cards selected
      setTimeout(() => {
        setAllRevealed(true);
        setTimeout(() => {
          onComplete([...selectedCards, card]);
        }, 1500);
      }, 1000);
    }
  };

  const posLabels = ['过去', '现在', '未来'];

  return (
    <div className="min-h-screen flex flex-col items-center px-4 py-8 md:py-12">
      {/* Header */}
      <div className="text-center mb-6 animate-fadeInUp">
        <h2 className="text-2xl md:text-3xl font-serif font-light text-golden tracking-wider mb-2">
          选择你的牌
        </h2>
        <Ornament className="mb-3" />
        <p className="text-xs text-ink-light/60 font-serif max-w-sm mx-auto">
          你的问题：「{question}」
        </p>
      </div>

      {/* Selection indicators */}
      <div className="flex gap-6 mb-8 animate-fadeInUp" style={{ animationDelay: '0.2s', opacity: 0 }}>
        {[0, 1, 2].map(i => (
          <div key={i} className="flex flex-col items-center gap-2">
            <div className={`w-12 h-16 md:w-14 md:h-20 rounded-lg border-2 transition-all duration-500
                            flex items-center justify-center text-xs font-serif
                            ${selectedCards[i] 
                              ? 'border-gold bg-gold/10 text-gold shadow-md shadow-gold/20' 
                              : 'border-gold-light/30 bg-cream-dark/30 text-ink-light/30'}`}>
              {selectedCards[i] ? (
                <span className="text-lg">{selectedCards[i].symbol}</span>
              ) : (
                <span className="text-gold-light/50 text-lg">?</span>
              )}
            </div>
            <span className={`text-xs font-serif transition-colors duration-300
                             ${selectedCards[i] ? 'text-gold' : 'text-ink-light/40'}`}>
              {posLabels[i]}
            </span>
          </div>
        ))}
      </div>

      {/* Instruction */}
      <p className={`text-sm font-serif mb-6 transition-all duration-500
                     ${selectedCards.length >= 3 ? 'text-gold' : 'text-ink-light/60'}`}>
        {isShuffling ? '牌正在洗牌中…' : 
         allRevealed ? '✦ 命运已揭示，正在解读… ✦' :
         `请选择第 ${selectedCards.length + 1} 张牌 — ${posLabels[selectedCards.length]}的位置`}
      </p>

      {/* Card Grid */}
      {isShuffling ? (
        <div className="flex items-center justify-center gap-4 py-20">
          {[0, 1, 2].map(i => (
            <div key={i} className={i % 2 === 0 ? 'shuffle-left' : 'shuffle-right'}
                 style={{ animationDelay: `${i * 0.15}s`, animationIterationCount: 3 }}>
              <CardBack />
            </div>
          ))}
        </div>
      ) : showCards ? (
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2 md:gap-3 max-w-5xl mx-auto">
          {shuffledCards.map((card, index) => (
            <div
              key={card.id}
              className="card-flip-container animate-fadeInUp"
              style={{ animationDelay: `${index * 0.03}s`, opacity: 0 }}
            >
              <button
                onClick={() => selectCard(card, index)}
                disabled={selectedCards.length >= 3 || flippedIndices.has(index)}
                className={`card-flip-inner block w-full ${flippedIndices.has(index) ? 'flipped' : ''}
                           ${!flippedIndices.has(index) && selectedCards.length < 3 ? 'tarot-card-hover cursor-pointer' : ''}
                           ${flippedIndices.has(index) ? '' : 'hover:scale-105'}`}
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* Card Back (default visible) */}
                <div className="card-face-front">
                  <div className={`w-full aspect-[2.5/4] rounded-lg
                                  bg-gradient-to-br from-mystic/80 via-lavender to-mystic/60
                                  border border-gold/30 flex items-center justify-center
                                  shadow-md relative overflow-hidden
                                  ${!flippedIndices.has(index) && selectedCards.length < 3 
                                    ? 'hover:border-gold/60 hover:shadow-gold/20' 
                                    : ''}`}>
                    <div className="absolute inset-1 border border-gold/15 rounded" />
                    <span className="text-gold/50 text-sm">☽</span>
                  </div>
                </div>
                {/* Card Front (shown when flipped) */}
                <div className="card-face-back absolute inset-0">
                  <div
                    className="w-full aspect-[2.5/4] rounded-lg border border-gold/40
                               flex flex-col items-center justify-center p-1.5 shadow-lg
                               relative overflow-hidden animate-cardGlow"
                    style={{
                      background: `linear-gradient(135deg, ${card.colors.from}, ${card.colors.to})`
                    }}
                  >
                    <span className="text-xl mb-0.5">{card.symbol}</span>
                    <span className="text-[8px] md:text-[9px] font-serif text-ink font-semibold tracking-wide">{card.name}</span>
                  </div>
                </div>
              </button>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

// ─── AI Reading Simulation ───
function simulateAIReading(question: string, cards: TarotCard[]): string {
  const pastCard = cards[0];
  const presentCard = cards[1];
  const futureCard = cards[2];

  const reading = `🌟 关于你的问题「${question}」，星辰塔罗为你揭示了以下启示：

═══ 第一张 · 过去 ═══
【${pastCard.name}】${pastCard.nameEn}
${pastCard.symbol} ${pastCard.element}
关键词：${pastCard.keywords.join('、')}

${pastCard.meaning}

在过去的位置上，${pastCard.name}告诉我们，你曾经历过与「${pastCard.keywords[0]}」和「${pastCard.keywords[1]}」相关的重要阶段。这段经历塑造了你现在面对这个问题的方式。${pastCard.name}的能量提醒你，过去的智慧是你前行的基石。

═══ 第二张 · 现在 ═══
【${presentCard.name}】${presentCard.nameEn}
${presentCard.symbol} ${presentCard.element}
关键词：${presentCard.keywords.join('、')}

${presentCard.meaning}

在当下的位置上，${presentCard.name}揭示了你目前正处于「${presentCard.keywords[0]}」的状态。这张牌暗示你现在需要关注的核心议题是${presentCard.keywords[2]}。宇宙正在通过这张牌告诉你：现在是${presentCard.keywords[3]}的最佳时机。

═══ 第三张 · 未来 ═══
【${futureCard.name}】${futureCard.nameEn}
${futureCard.symbol} ${futureCard.element}
关键词：${futureCard.keywords.join('、')}

${futureCard.meaning}

在未来的位置上，${futureCard.name}为你指明了前方的道路。这张牌预示着「${futureCard.keywords[0]}」与「${futureCard.keywords[1]}」的能量将在你的生活中显现。这是一个充满${futureCard.keywords[2]}的信号。

═══ 综合解读 ═══

从整体牌阵来看，过去的${pastCard.name}（${pastCard.keywords[0]}）引导你走到了现在${presentCard.name}（${presentCard.keywords[0]}）的状态，而未来的${futureCard.name}则为你指明了${futureCard.keywords[0]}的方向。

这三张牌共同传达的信息是：你正在经历一段重要的转变期。过去的经验已经为你积累了足够的智慧，现在你需要做的是信任自己的直觉，勇敢地朝着未来迈步。

✧ 星辰寄语 ✧
宇宙的安排总是恰到好处的。无论眼前的道路看起来多么不确定，请记住——每一颗星辰都曾是黑暗中的一粒尘埃，而你，正如星辰般闪耀。

愿星光指引你的旅途 ✦`;

  return reading;
}

// ─── Page: Reading Result ───
function ReadingPage({ 
  question, 
  cards, 
  onRestart 
}: { 
  question: string; 
  cards: TarotCard[];
  onRestart: () => void;
}) {
  const [displayText, setDisplayText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  const [showCards, setShowCards] = useState(false);
  const [revealedCards, setRevealedCards] = useState<boolean[]>([false, false, false]);
  const fullTextRef = useRef('');
  const readingContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // First show cards with stagger
    setTimeout(() => setShowCards(true), 300);
    setTimeout(() => setRevealedCards([true, false, false]), 800);
    setTimeout(() => setRevealedCards([true, true, false]), 1300);
    setTimeout(() => setRevealedCards([true, true, true]), 1800);

    // Then start AI reading
    const fullText = simulateAIReading(question, cards);
    fullTextRef.current = fullText;
    
    let currentIndex = 0;
    const startTyping = setTimeout(() => {
      const interval = setInterval(() => {
        if (currentIndex < fullText.length) {
          const charsToAdd = Math.random() > 0.9 ? 3 : Math.random() > 0.7 ? 2 : 1;
          currentIndex = Math.min(currentIndex + charsToAdd, fullText.length);
          setDisplayText(fullText.slice(0, currentIndex));
        } else {
          clearInterval(interval);
          setIsTyping(false);
        }
      }, 30);
      
      return () => clearInterval(interval);
    }, 2500);
    
    return () => clearTimeout(startTyping);
  }, [question, cards]);

  // Auto-scroll during typing
  useEffect(() => {
    if (readingContainerRef.current && isTyping) {
      readingContainerRef.current.scrollTop = readingContainerRef.current.scrollHeight;
    }
  }, [displayText, isTyping]);

  const skipToEnd = () => {
    setDisplayText(fullTextRef.current);
    setIsTyping(false);
  };

  const posLabels = ['过去', '现在', '未来'];
  const posDescs = ['影响现状的过去因素', '当前的处境与能量', '可能的发展方向'];

  return (
    <div className="min-h-screen flex flex-col items-center px-4 py-8 md:py-12">
      {/* Header */}
      <div className="text-center mb-8 animate-fadeInUp">
        <h2 className="text-2xl md:text-3xl font-serif font-light text-golden tracking-wider mb-2">
          星辰解读
        </h2>
        <Ornament className="mb-3" />
        <p className="text-xs text-ink-light/50 font-serif">
          「{question}」
        </p>
      </div>

      {/* Three Cards Display */}
      {showCards && (
        <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-10">
          {cards.map((card, i) => (
            <div
              key={card.id}
              className={`flex flex-col items-center transition-all duration-700 
                         ${revealedCards[i] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
              style={{ transitionDelay: `${i * 0.3}s` }}
            >
              <p className="text-xs font-serif text-gold mb-1">{posLabels[i]}</p>
              <p className="text-[10px] font-serif text-ink-light/40 mb-2">{posDescs[i]}</p>
              <div className="animate-cardGlow rounded-xl">
                <CardFront card={card} />
              </div>
              <div className="mt-3 text-center">
                <p className="text-sm font-serif text-ink font-semibold">{card.name}</p>
                <p className="text-[10px] font-display italic text-ink-light/50">{card.nameEn}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <Ornament className="mb-6" />

      {/* AI Reading */}
      <div className="w-full max-w-2xl">
        <div className="bg-white/40 backdrop-blur-sm rounded-2xl border border-gold-light/30 p-6 md:p-8 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-gold text-sm">✦</span>
            <h3 className="text-lg font-serif text-golden tracking-wider">塔罗解读</h3>
            {isTyping && (
              <div className="flex gap-1 ml-2">
                <span className="w-1.5 h-1.5 bg-gold/60 rounded-full typing-dot" />
                <span className="w-1.5 h-1.5 bg-gold/60 rounded-full typing-dot" />
                <span className="w-1.5 h-1.5 bg-gold/60 rounded-full typing-dot" />
              </div>
            )}
          </div>
          
          <div 
            ref={readingContainerRef}
            className="max-h-[60vh] overflow-y-auto pr-2 scroll-smooth"
          >
            <div className="font-serif text-sm text-ink leading-relaxed whitespace-pre-wrap">
              {displayText}
              {isTyping && <span className="inline-block w-0.5 h-4 bg-gold/60 ml-0.5 animate-pulse" />}
            </div>
          </div>

          {isTyping && (
            <button
              onClick={skipToEnd}
              className="mt-4 text-xs font-serif text-ink-light/50 hover:text-gold transition-colors duration-300"
            >
              跳过动画 →
            </button>
          )}
        </div>

        {/* Affirmation card */}
        {!isTyping && (
          <div className="mt-6 animate-fadeInUp" style={{ opacity: 0 }}>
            <div className="bg-rose-light/30 rounded-2xl border border-rose/30 p-6 text-center">
              <p className="text-xs font-serif text-ink-light/60 mb-2">✧ 每日肯定语 ✧</p>
              <p className="font-serif text-ink text-sm italic leading-relaxed">
                "我信任宇宙的安排，每一步都引领我走向最好的自己。<br />
                我是光，我是爱，我是无限的可能。"
              </p>
            </div>
          </div>
        )}

        {/* Restart button */}
        {!isTyping && (
          <div className="mt-8 text-center animate-fadeInUp" style={{ animationDelay: '0.3s', opacity: 0 }}>
            <button
              onClick={onRestart}
              className="px-8 py-3 rounded-xl font-serif text-sm tracking-widest
                         bg-gradient-to-r from-gold-dark/90 via-gold to-gold-dark/90
                         text-cream border border-gold-light/50
                         hover:shadow-lg hover:shadow-gold/20 hover:scale-[1.02]
                         transition-all duration-300"
            >
              ✦ 重新占卜 ✦
            </button>
            <p className="mt-4 text-xs text-ink-light/30 font-display italic">
              每一次占卜都是一次与宇宙的对话
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Page Transition Wrapper ───
function PageTransition({ children, pageKey }: { children: React.ReactNode; pageKey: string }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(false);
    const timer = setTimeout(() => setVisible(true), 50);
    return () => clearTimeout(timer);
  }, [pageKey]);

  return (
    <div className={`transition-all duration-700 ${visible ? 'opacity-100' : 'opacity-0'}`}>
      {children}
    </div>
  );
}

// ─── Main App ───
type AppPage = 'landing' | 'selection' | 'reading';

export function App() {
  const [page, setPage] = useState<AppPage>('landing');
  const [question, setQuestion] = useState('');
  const [selectedCards, setSelectedCards] = useState<TarotCard[]>([]);
  const [transitioning, setTransitioning] = useState(false);

  const transitionTo = (nextPage: AppPage) => {
    setTransitioning(true);
    setTimeout(() => {
      setPage(nextPage);
      setTransitioning(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 500);
  };

  const handleQuestionSubmit = (q: string) => {
    setQuestion(q);
    transitionTo('selection');
  };

  const handleCardsSelected = (cards: TarotCard[]) => {
    setSelectedCards(cards);
    transitionTo('reading');
  };

  const handleRestart = () => {
    setQuestion('');
    setSelectedCards([]);
    transitionTo('landing');
  };

  return (
    <div className="min-h-screen bg-cream bg-pattern relative overflow-x-hidden">
      <StarParticles />
      <AudioController />
      
      <div className={`relative z-10 transition-opacity duration-500 ${transitioning ? 'opacity-0' : 'opacity-100'}`}>
        <PageTransition pageKey={page}>
          {page === 'landing' && (
            <LandingPage onSubmit={handleQuestionSubmit} />
          )}
          {page === 'selection' && (
            <CardSelectionPage 
              question={question} 
              onComplete={handleCardsSelected} 
            />
          )}
          {page === 'reading' && (
            <ReadingPage 
              question={question} 
              cards={selectedCards} 
              onRestart={handleRestart}
            />
          )}
        </PageTransition>
      </div>

      {/* Bottom decoration */}
      <div className="fixed bottom-0 left-0 right-0 h-16 pointer-events-none z-0
                      bg-gradient-to-t from-cream/80 to-transparent" />
    </div>
  );
}
